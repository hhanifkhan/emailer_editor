//grid template
const gridTemplatesAll = {
	"grid_1" : `
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tr>
			<td ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)"><h2>oye</h2></td>
		</tr>
	</table>`,
	"grid_2" : `
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tr>
			<td width="50%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">1</td>
			<td width="50%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">2</td>
		</tr>
	</table>`,
	"grid_2_1/3" : `
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tr>
			<td width="70%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">1</td>
			<td width="30%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">2</td>
		</tr>
	</table>`,
	"grid_2_3/1" : `
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tr>
			<td width="30%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">1</td>
			<td width="70%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">2</td>
		</tr>
	</table>`,
	"grid_3" : `
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tr>
			<td width="33%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">1</td>
			<td width="33%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">2</td>
			<td width="33%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">3</td>
		</tr>
	</table>
	`,
	"grid_4" : `
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tr>
			<td ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">1</td>
			<td ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">2</td>
			<td ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">3</td>
			<td ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">4</td>
		</tr>
	</table>
	`
};

//grid template end
const componentAll={
	"ck_text" : `<p class="editor" ondblclick="makeEditable(event,this)" data-ce="1">Hello Hi Pakiya !!</p>`,
	"ck_button" : `<input type="button" value="Button" />`,
	"ck_blankrow" : `<p style=" background-color:red;">Reference site about Lorem Ipsum, giving information on its origins, as well as a random Lipsum generator.</p>`,
	"ck_seprator" : `<p style="border-bottom:2px solid #000;"></p>`,
	"ck_raw" : `<h1  class="editor" ondblclick="makeEditable(event,this)" data-ce="1">Why do we use it?</h1>`,
	"ck_image" : `<img src="https://images5.alphacoders.com/637/thumb-1920-637668.jpg" class="ve_image" width="100%" style="    border: 1px solid green;
    color: red;
    font-size: 10px;
    height: auto;
    width: 100%;" />`

};

//component
const componentProps={
	"css_rules" : {
		fm : "fontFamily",
		fs : "fontSize",
		co : "color",
		fw : "fontWeight",
		lh : "lineHeight",
		ta : "textAlign",
		td : "textDecoration",
		bg : "backgroundColor",
		bo : "border",
		he : "height",
		wi : "width",
		mw : "maxWidth",
		dp : "display"
	},
	"attrib" : {
		at : "alt",
		al : "align",
		va : "valign",
		wi : "width",
		he : "height",
		ce : "cellpadding",
		cs : "cellspacing",
		bg : "bgcolor",
		hr : "href",
		tr : "target",
		sr : "src"

	},
	"image_prop" : { 
		"css" : ["co", "wi", "he", "bo"],
		"atr" : ["sr","at"]
	}
};

//component end

var o={
	ve_Wrapper : document.querySelector(".wrapper"),
	ve_grids : gridTemplatesAll
};

o.tabs = document.querySelectorAll(".tabs a"); 
o.contentAllDiv = document.querySelectorAll(".tab_content"); 
o.filterOption = function(){
	o.tabs.forEach(function(c,i,a){
		c.addEventListener('click',function(){
			document.querySelectorAll(".attrPropContainer")[0].classList.remove("isActive");
			var targetContentID = this.getAttribute('data-id');
			o.tabs.forEach(function(c2,i2,a2){
				c2.removeAttribute("class");
			});
			this.classList.add('isactiveTab');
			o.contentAllDiv.forEach(function(c3,i3,a3){
				c3.removeAttribute("style");
			});
			document.getElementById(targetContentID).style.display="block";
		});
	});
};
o.initImageEdit = function(){
	document.querySelector("body").addEventListener("click",function(e){
		if(e.target && e.target.matches("img.ve_image")){
		
			var imgCssProp = componentProps.image_prop.css,
				imgAttr = componentProps.image_prop.atr,
				formTemp = `<h3 class="tab_content__h3">PROPERTIES</h3><form name="ve_image">`;

			//toggle component panel
			document.querySelectorAll(".attrPropContainer")[0].classList.toggle("isActive");	

			//loop all css props
			imgCssProp.forEach(function(element, index) {
				var tmpCssPropVal = componentProps.css_rules[element];
				console.log(e.target.style[tmpCssPropVal]);
				formTemp += `<div class="tab_content_prop__item clr">
					<p>${tmpCssPropVal}</p>
					<span>
						<label data-label="X">
							<input type="text" name="${tmpCssPropVal}" value="${e.target.style[tmpCssPropVal]}">
						</label>
					</span>
				</div>`;
			});

			//add update button
			formTemp += `<div onclick="renderUpdatedData('ve_image')" class="btnUpdate">Update</div></form>`;

			//loop all attribute
			imgAttr.forEach(function(element, index) {
				var tmpCssPropVal = componentProps.attrib[element];
				console.log(e.target.getAttribute(tmpCssPropVal));
				formTemp += `<p>${tmpCssPropVal}</p><input type="text" value="${e.target.getAttribute(tmpCssPropVal)}" />`;
				
			});
			formTemp += `<div class="btnUpdate">Update</div></form>`;

			//inject to dom element
			document.getElementById("showAllProp").innerHTML = formTemp;
			console.log(imgAttr);

		}

	})
};

function renderUpdatedData(formName){
	console.log();
	// console.log(document.forms[formName]);
	// console.log(document.forms[formName].elements);
	var elements = document.forms[formName].elements,
		cssString="";

	for(var key in elements){
		cssString += elements[key].name +":"+ elements[key].value+";";
	}
	
	console.log(cssString);
	document.querySelectorAll("."+formName)[0].style.cssText = cssString;

}

o.addNewTemplate = function(){
	var el = document.querySelector(".w_block_addTemplateElement");
	el.addEventListener("click",function(){
		o.ve_Wrapper.classList.toggle('NotEditable');
	});
};
o.init=function(){
	o.filterOption();
	o.initDragula();
	o.initImageEdit();
	//o.addNewTemplate();
};



//----------------
//left==what drag
//right=where drop
var drake;
o.initDragula = function(){
	drake = dragula([document.getElementById("left"), document.getElementById("right")], {
	  copy: function (el, source, handle, sibling) {
	  	// console.log("el,source====>");
	  	// console.log(el,source);
	  	// console.log("el,source,handle,sibling====<");	
	  	// var gridkey = el.getAttribute("data-gridKey");
	  	// el.classList.add("hanif");
	  	// el.classList = "grid";
	  	//el.innerHTML = o.ve_grids[gridkey];
	    return source === document.getElementById("left");

	  },
	  accepts: function (el, target,source, sibling) {
	  	// console.log(el,target,source,sibling);
	    return target !== document.getElementById("left");

	  }
	});

	drake.on('drop',function(el, target, source, sibling){
		// console.log("el,source====>");
	 //  	console.log(el,source, source, sibling);
	  	if(!el.classList.contains("isGridAlreadyAdded")){	
		  	var gridkey = el.getAttribute("data-gridKey");
		  	el.classList = "grid";
		  	el.classList.add("isGridAlreadyAdded");
		  	el.innerHTML = o.ve_grids[gridkey];
	    }
	  	// console.log("el,source,handle,sibling====<");	
	});
}

// dragula([document.getElementById("tc1"), document.getElementsByClassName("hanif")[0]], {
//   copy: function (el, source) {
//     return source === document.getElementById("tc1");
//   },
//   accepts: function (el, target) {
//     return target !== document.getElementById("tc1");
//   }
// });

function handleAllowDrop(ev){
	ev.preventDefault();
}


function allowDrop(ev) {
  ev.preventDefault();
}

function drag(ev,el) {
	console.log("drag wala event");
	console.log(el);
	console.log(el.getAttribute("data-componentKey"));
	console.log(ev);
	console.log(ev.srcElement.getAttribute("id"));
	var getComponentKey = el.getAttribute("data-componentKey");
  // ev.dataTransfer.setData("text/html", ev.target.id);
  ev.dataTransfer.setData("text/html", componentAll[getComponentKey]);
}

function handleDrop(ev,el){
	ev.preventDefault();
	console.log("handleDrop===>asdasd");
	console.log(ev,el);
	console.log("<===asdasd");
	var data=ev.dataTransfer.getData("text/html");
  	console.log(data);
  	el.innerHTML +=  data;

}

// var _p = document.querySelectorAll(".ptag");

// _p.forEach( function(element, index) {
// 	element.addEventListener("click",function(){
// 		console.log(this);
// 	});
// });

// //ptagclick
// function ptagclick(el){
// 	console.log(el);
// 	console.log(el.style.color);
// }


o.init();



// var quill = new Quill(document.querySelectorAll(".editor"), {
//   modules: {
//     toolbar: [
//       [{ header: [1, 2, false] }],
//       ['bold', 'italic', 'underline'],
//       [{ 'color': [] }, { 'background': [] }],
//       ['image']
//     ]
//   },
//   // scrollingContainer: '#scrolling-container', 
//   placeholder: 'Compose an epic...',
//   theme: 'bubble'
// });


function makeEditable(e,t){

	var elements = document.querySelectorAll('.editor'),
    editor = new MediumEditor(elements, {
    toolbar: {
        buttons: ['bold', 'italic', 'underline', 'anchor', 'image',
         'strikethrough','orderedlist','unorderedlist','justifyLeft','justifyCenter','justifyRight','justifyFull',
         'html'
         ]
    }
});
}