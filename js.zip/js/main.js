//grid template
const gridTemplatesAll = {
	"grid_1" : `
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tr>
			<td ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)"><h2>oye</h2></td>
		</tr>
	</table>`,
	"grid_2" : `
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tr>
			<td width="50%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">1</td>
			<td width="50%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">2</td>
		</tr>
	</table>`,
	"grid_2_1/3" : `
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tr>
			<td width="70%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">1</td>
			<td width="30%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">2</td>
		</tr>
	</table>`,
	"grid_2_3/1" : `
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tr>
			<td width="30%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">1</td>
			<td width="70%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">2</td>
		</tr>
	</table>`,
	"grid_3" : `
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tr>
			<td width="33%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">1</td>
			<td width="33%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">2</td>
			<td width="33%" ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">3</td>
		</tr>
	</table>
	`,
	"grid_4" : `
	<table cellpadding="0" cellspacing="0" border="0" width="100%">
		<tr>
			<td ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">1</td>
			<td ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">2</td>
			<td ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">3</td>
			<td ondrop="handleDrop(event,this)" ondragover="handleAllowDrop(event)">4</td>
		</tr>
	</table>
	`
};
//grid template end
const componentAll={
	"ck_text" : `<p class="editor" ondblclick="makeEditable(event,this)" data-ce="1">Hello Hi Pakiya !!</p>`,
	"ck_button" : `<input type="button" value="Button" />`,
	"ck_blankrow" : `<p style=" background-color:red;">Reference site about Lorem Ipsum, giving information on its origins, as well as a random Lipsum generator.</p>`,
	"ck_seprator" : `<p style="border-bottom:2px solid #000;"></p>`,
	"ck_raw" : `<h1  class="editor" ondblclick="makeEditable(event,this)" data-ce="1">Why do we use it?</h1>`
}
//component

//component end

var o={
	ve_Wrapper : document.querySelector(".wrapper"),
	ve_grids : gridTemplatesAll
};

o.tabs = document.querySelectorAll(".tabs a"); 
o.contentAllDiv = document.querySelectorAll(".tab_content"); 
o.filterOption = function(){
	o.tabs.forEach(function(c,i,a){
		c.addEventListener('click',function(){
			var targetContentID = this.getAttribute('data-id');
			o.tabs.forEach(function(c2,i2,a2){
				c2.removeAttribute("class");
			});
			this.classList.add('isactiveTab');
			o.contentAllDiv.forEach(function(c3,i3,a3){
				c3.removeAttribute("style");
			});
			document.getElementById(targetContentID).style.display="block";
		});
	});
};
o.addNewTemplate = function(){
	var el = document.querySelector(".w_block_addTemplateElement");
	el.addEventListener("click",function(){
		o.ve_Wrapper.classList.toggle('NotEditable');
	});
};
o.init=function(){
	o.filterOption();
	o.initDragula();
	//o.addNewTemplate();
};



//----------------
//left==what drag
//right=where drop
var drake;
o.initDragula = function(){
	drake = dragula([document.getElementById("left"), document.getElementById("right")], {
	  copy: function (el, source, handle, sibling) {
	  	// console.log("el,source====>");
	  	// console.log(el,source);
	  	// console.log("el,source,handle,sibling====<");	
	  	// var gridkey = el.getAttribute("data-gridKey");
	  	// el.classList.add("hanif");
	  	// el.classList = "grid";
	  	//el.innerHTML = o.ve_grids[gridkey];
	    return source === document.getElementById("left");

	  },
	  accepts: function (el, target,source, sibling) {
	  	// console.log(el,target,source,sibling);
	    return target !== document.getElementById("left");

	  }
	});

	drake.on('drop',function(el, target, source, sibling){
		// console.log("el,source====>");
	 //  	console.log(el,source, source, sibling);
	  	if(!el.classList.contains("isGridAlreadyAdded")){	
		  	var gridkey = el.getAttribute("data-gridKey");
		  	el.classList = "grid";
		  	el.classList.add("isGridAlreadyAdded");
		  	el.innerHTML = o.ve_grids[gridkey];
	    }
	  	// console.log("el,source,handle,sibling====<");	
	});
}

// dragula([document.getElementById("tc1"), document.getElementsByClassName("hanif")[0]], {
//   copy: function (el, source) {
//     return source === document.getElementById("tc1");
//   },
//   accepts: function (el, target) {
//     return target !== document.getElementById("tc1");
//   }
// });

function handleAllowDrop(ev){
	ev.preventDefault();
}


function allowDrop(ev) {
  ev.preventDefault();
}

function drag(ev,el) {
	console.log("drag wala event");
	console.log(el);
	console.log(el.getAttribute("data-componentKey"));
	console.log(ev);
	console.log(ev.srcElement.getAttribute("id"));
	var getComponentKey = el.getAttribute("data-componentKey");
  // ev.dataTransfer.setData("text/html", ev.target.id);
  ev.dataTransfer.setData("text/html", componentAll[getComponentKey]);
}

function handleDrop(ev,el){
	ev.preventDefault();
	console.log("handleDrop===>asdasd");
	console.log(ev,el);
	console.log("<===asdasd");
	var data=ev.dataTransfer.getData("text/html");
  	console.log(data);
  	el.innerHTML +=  data;

}


var _p = document.querySelectorAll(".ptag");

_p.forEach( function(element, index) {
	element.addEventListener("click",function(){
		console.log(this);
	});
});

//ptagclick
function ptagclick(el){
	console.log(el);
	console.log(el.style.color);
}


o.init();



// var quill = new Quill(document.querySelectorAll(".editor"), {
//   modules: {
//     toolbar: [
//       [{ header: [1, 2, false] }],
//       ['bold', 'italic', 'underline'],
//       [{ 'color': [] }, { 'background': [] }],
//       ['image']
//     ]
//   },
//   // scrollingContainer: '#scrolling-container', 
//   placeholder: 'Compose an epic...',
//   theme: 'bubble'
// });


function makeEditable(e,t){
	 /**
     * Custom `color picker` extension
     */
    var ColorPickerExtension = MediumEditor.Extension.extend({
      name: "colorPicker",

      init: function () {
        this.button = this.document.createElement('button');
        this.button.classList.add('medium-editor-action');
        this.button.classList.add('editor-color-picker');
        this.button.title = 'Text color'
        this.button.innerHTML = '<i class="fa fa-paint-brush"></i>';

        this.on(this.button, 'click', this.handleClick.bind(this));
      },

      getButton: function () {
        return this.button;
      },

      handleClick: function (e) {
        e.preventDefault();
        e.stopPropagation();

        this.selectionState = this.base.exportSelection();

        // If no text selected, stop here.
        if (this.selectionState && (this.selectionState.end - this.selectionState.start === 0)) {
          return;
        }

        // colors for picker
        var pickerColors = [
          "#1abc9c",
          "#2ecc71",
          "#3498db",
          "#9b59b6",
          "#34495e",
          "#16a085",
          "#27ae60",
          "#2980b9",
          "#8e44ad",
          "#2c3e50",
          "#f1c40f",
          "#e67e22",
          "#e74c3c",
          "#bdc3c7",
          "#95a5a6",
          "#f39c12"
        ];

        var picker = vanillaColorPicker(this.document.querySelector(".medium-editor-toolbar-active .editor-color-picker").parentNode);
        picker.set("customColors", pickerColors);
        picker.set("positionOnTop");
        picker.openPicker();
        picker.on("colorChosen", function (color) {
          this.base.importSelection(this.selectionState);
          this.document.execCommand("styleWithCSS", false, true);
          this.document.execCommand("foreColor", false, color);
        }.bind(this));
      }
    });



	// var editor = new MediumEditor('.editor');
	var editor = new MediumEditor('.editor', {
	  toolbar: {
	    buttons: ['bold', 'italic','anchor', 'underline', 'colorPicker']
	  },
	  extensions: {
	    'colorPicker': new ColorPickerExtension()
	  }
	});
}